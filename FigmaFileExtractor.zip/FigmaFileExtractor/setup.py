#!/usr/bin/env python3
"""
Setup script for Figma File Extractor MCP Server
This script helps with initial setup and dependency installation.
"""

import os
import sys
import subprocess
import platform


def run_command(command, description):
    """Run a command and handle errors"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed:")
        print(f"   Error: {e.stderr}")
        return False


def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python 3.8 or higher is required")
        print(f"   Current version: {sys.version}")
        return False
    print(f"✅ Python version {version.major}.{version.minor}.{version.micro} is compatible")
    return True


def install_dependencies():
    """Install required dependencies"""
    dependencies = [
        "mcp>=1.0.0",
        "httpx>=0.24.0", 
        "pydantic>=2.0.0"
    ]
    
    print("📦 Installing dependencies...")
    for dep in dependencies:
        if not run_command(f"pip install \"{dep}\"", f"Installing {dep}"):
            return False
    return True


def setup_environment():
    """Guide user through environment setup"""
    print("\n🔐 Environment Setup")
    print("=" * 30)
    
    # Check if token already exists
    existing_token = os.getenv("FIGMA_ACCESS_TOKEN")
    if existing_token:
        print(f"✅ FIGMA_ACCESS_TOKEN is already set: {existing_token[:10]}...")
        return True
    
    print("❌ FIGMA_ACCESS_TOKEN environment variable not found")
    print()
    print("📋 To get your Figma Personal Access Token:")
    print("   1. Go to https://www.figma.com/settings")
    print("   2. Scroll to 'Personal Access Tokens'")
    print("   3. Click 'Create a new personal access token'")
    print("   4. Give it a name (e.g., 'MCP Server')")
    print("   5. Copy the generated token")
    print()
    
    token = input("🔑 Paste your Figma Personal Access Token here (or press Enter to skip): ").strip()
    
    if not token:
        print("⚠️  Skipping token setup. You'll need to set it later.")
        return False
    
    # Create .env file
    env_file = ".env"
    try:
        with open(env_file, "w") as f:
            f.write(f"FIGMA_ACCESS_TOKEN={token}\n")
        print(f"✅ Token saved to {env_file}")
        
        # Set for current session
        os.environ["FIGMA_ACCESS_TOKEN"] = token
        print("✅ Token set for current session")
        
        # Provide instructions for permanent setup
        system = platform.system().lower()
        print("\n📌 To make this permanent, add to your shell profile:")
        if system == "windows":
            print(f"   PowerShell: $env:FIGMA_ACCESS_TOKEN='{token}'")
            print(f"   CMD: set FIGMA_ACCESS_TOKEN={token}")
        else:
            print(f"   export FIGMA_ACCESS_TOKEN='{token}'")
        
        return True
        
    except Exception as e:
        print(f"❌ Failed to save token: {e}")
        return False


def test_installation():
    """Test the installation"""
    print("\n🧪 Testing Installation")
    print("=" * 25)
    
    try:
        # Test imports
        print("🔄 Testing imports...")
        import mcp
        import httpx
        import pydantic
        print("✅ All dependencies imported successfully")
        
        # Test server initialization (without running)
        print("🔄 Testing server initialization...")
        from main import server, initialize_figma_client
        
        if os.getenv("FIGMA_ACCESS_TOKEN"):
            initialize_figma_client()
            print("✅ Figma client initialized successfully")
        else:
            print("⚠️  Figma client not initialized (no token)")
        
        print("✅ Server setup looks good!")
        return True
        
    except Exception as e:
        print(f"❌ Installation test failed: {e}")
        return False


def main():
    """Main setup function"""
    print("🚀 Figma File Extractor MCP Server - Setup")
    print("=" * 45)
    print()
    
    # Check Python version
    if not check_python_version():
        return 1
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed during dependency installation")
        return 1
    
    # Setup environment
    setup_environment()
    
    # Test installation
    if not test_installation():
        print("\n❌ Setup completed but tests failed")
        return 1
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("   1. Run: python main.py")
    print("   2. Or try: python example_usage.py")
    print("   3. Or integrate with Claude Desktop (see README.md)")
    print()
    print("📚 For more information, see README.md")
    
    return 0


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n👋 Setup cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error during setup: {e}")
        sys.exit(1)