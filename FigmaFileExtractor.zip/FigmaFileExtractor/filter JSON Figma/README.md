# Figma JSON Structure for React Rendering

This folder contains structured and filtered JSON files extracted from the Figma design file, organized for easy React component development.

## File Structure

### 📄 Core Files

- **`file-metadata.json`** - Basic file information, pages, and document structure
- **`components.json`** - Main component instances with properties and layout info
- **`layout-structure.json`** - Hierarchical layout structure for component nesting

### 🎨 UI Elements

- **`text-elements.json`** - All text content with styling and typography
- **`buttons.json`** - Button components with states and properties  
- **`input-fields.json`** - Form fields and input components
- **`design-tokens.json`** - Colors, typography styles, and visual effects

### ⚛️ React Integration

- **`react-component-map.json`** - Direct mapping to React component structure
- **`component-library.json`** - Figma component library with variants

## React Component Structure

Based on the Figma design, the main Alert component structure is:

```jsx
<Alert showFields={true} showField2={true} type="Stacked" mode="Light">
  <AlertBackground mode="Light" />
  <AlertContent>
    <AlertTitle>A Short Title Is Best</AlertTitle>
    <AlertDescription>A description should be a short, complete sentence.</AlertDescription>
  </AlertContent>
  <AlertFields showFields={true}>
    <TextField state="value-entered" />
    <TextField state="placeholder" showField2={true} />
  </AlertFields>
  <AlertButtons>
    <Button type="primary" mode="Light">Primary</Button>
    <Button type="destructive" mode="Light">Destructive</Button>
    <Button type="secondary" mode="Light">Secondary</Button>
  </AlertButtons>
</Alert>
```

## Design Tokens

### Colors
- **Fuschia**: 100, 80, 60 variations
- **Iris**: 100, 80, 60 variations

### Typography
- **Header 1**: Primary headings
- **Header 2**: Secondary headings  
- **Body**: Regular text content

### Effects
- **Glass Morphism**: Shadow, blur, and glass effects for modern UI

## Layout Properties

The Alert component uses:
- **Vertical Layout**: Flex column with 10px gaps
- **Center Alignment**: All content centered
- **Responsive Padding**: 14px on all sides
- **Glass Background**: Modern glassmorphism effect
- **Conditional Rendering**: Fields show/hide based on properties

## Usage in React

1. Import the JSON files as needed
2. Map Figma IDs to React component props
3. Use the layout structure for CSS/styled-components
4. Apply design tokens for consistent styling
5. Handle conditional rendering based on component properties

This structure allows for direct translation from Figma design to React components while maintaining design system consistency.