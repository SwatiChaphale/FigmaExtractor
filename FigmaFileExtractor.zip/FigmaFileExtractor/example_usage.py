"""
Example usage script for the Figma File Extractor MCP Server

This script demonstrates how to interact with the Figma API
through the MCP server programmatically.
"""

import asyncio
import os
import json
from main import FigmaClient, FigmaAPIError


async def example_usage():
    """Example usage of the Figma client"""
    
    # Check if access token is available
    access_token = os.getenv("FIGMA_ACCESS_TOKEN")
    if not access_token:
        print("❌ Please set the FIGMA_ACCESS_TOKEN environment variable")
        print("   Get your token from: https://www.figma.com/settings")
        return
    
    # Initialize the client
    client = FigmaClient(access_token)
    
    # Example file key - replace with a real one
    # You can get this from a Figma URL like:
    # https://www.figma.com/file/ABC123DEF456/My-Design-File
    # where ABC123DEF456 is the file key
    example_file_key = "tQjyApQ24o5Ebhzir3gxaY"  # Using your provided file key
    
    print(f"🔄 Attempting to fetch Figma file: {example_file_key}")
    print(f"   Using token: {access_token[:10]}...")
    
    try:
        # Fetch the file
        file_data = await client.get_file(example_file_key)
        
        # Display basic information
        print("\n✅ File retrieved successfully!")
        print(f"📄 Name: {file_data.get('name', 'Unknown')}")
        print(f"🔢 Version: {file_data.get('version', 'Unknown')}")
        print(f"⏰ Last Modified: {file_data.get('lastModified', 'Unknown')}")
        
        # Display document structure
        document = file_data.get('document', {})
        children = document.get('children', [])
        print(f"📋 Document has {len(children)} top-level children")
        
        if children:
            print("\n📁 Top-level pages/frames:")
            for i, child in enumerate(children[:5]):  # Show first 5
                print(f"   {i+1}. {child.get('name', 'Unnamed')} ({child.get('type', 'Unknown type')})")
            if len(children) > 5:
                print(f"   ... and {len(children) - 5} more")
        
        # Save full response to file for inspection
        output_file = f"figma_file_{example_file_key}.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(file_data, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Full response saved to: {output_file}")
        
    except FigmaAPIError as e:
        print(f"\n❌ Figma API Error: {e}")
        print("\n🔍 Troubleshooting tips:")
        print("   • Verify the file key is correct")
        print("   • Check if you have access to this file")
        print("   • Ensure your access token is valid")
        print("   • Make sure the file exists and isn't deleted")
        
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")


def print_setup_instructions():
    """Print setup instructions for users"""
    print("🚀 Figma File Extractor - Example Usage")
    print("=" * 50)
    print()
    print("📋 Setup Instructions:")
    print("1. Get your Figma Personal Access Token:")
    print("   • Go to https://www.figma.com/settings")
    print("   • Scroll to 'Personal Access Tokens'")
    print("   • Create a new token")
    print()
    print("2. Set the environment variable:")
    print("   • Windows PowerShell: $env:FIGMA_ACCESS_TOKEN='your_token'")
    print("   • Windows CMD: set FIGMA_ACCESS_TOKEN=your_token")
    print("   • Linux/Mac: export FIGMA_ACCESS_TOKEN='your_token'")
    print()
    print("3. Update the file key in this script:")
    print("   • Find a Figma file URL: https://www.figma.com/file/ABC123/Name")
    print("   • Copy the file key (ABC123 part)")
    print("   • Replace 'ABC123DEF456' in this script")
    print()
    print("4. Run this script:")
    print("   • python example_usage.py")
    print()


if __name__ == "__main__":
    print_setup_instructions()
    
    # Ask user if they want to proceed
    try:
        proceed = input("Press Enter to continue with example (or Ctrl+C to exit): ")
        print()
        asyncio.run(example_usage())
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"\n❌ Error running example: {e}")
        print("Make sure you have installed the required dependencies:")
        print("pip install mcp httpx pydantic")