#!/usr/bin/env python3
"""
Figma File Extractor MCP Server

This server provides tools to interact with the Figma API to fetch file information.
"""

import asyncio
import os
import sys
from typing import Any, Dict, List, Optional
import logging

import httpx
from mcp.server import Server, NotificationOptions
from mcp.server.models import InitializationOptions
import mcp.server.stdio as stdio_server
import mcp.types as types
from pydantic import AnyUrl


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the MCP server
server = Server("figma-file-extractor")

class FigmaAPIError(Exception):
    """Custom exception for Figma API errors"""
    pass

class FigmaClient:
    """Client for interacting with the Figma API"""
    
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.base_url = "https://api.figma.com/v1"
        self.headers = {
            "X-FIGMA-TOKEN": access_token,
            "Content-Type": "application/json"
        }
    
    async def get_file(self, file_key: str) -> Dict[str, Any]:
        """
        Fetch a Figma file by its key
        
        Args:
            file_key: The Figma file key (found in the URL)
            
        Returns:
            Dict containing the file data
            
        Raises:
            FigmaAPIError: If the API request fails
        """
        url = f"{self.base_url}/files/{file_key}"
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                error_msg = f"HTTP {e.response.status_code}: {e.response.text}"
                logger.error(f"Figma API request failed: {error_msg}")
                raise FigmaAPIError(error_msg)
            except Exception as e:
                logger.error(f"Unexpected error during API request: {str(e)}")
                raise FigmaAPIError(f"Unexpected error: {str(e)}")

# Global Figma client (will be initialized with access token)
figma_client: Optional[FigmaClient] = None

def initialize_figma_client():
    """Initialize the Figma client with access token from environment"""
    global figma_client
    
    access_token = os.getenv("FIGMA_ACCESS_TOKEN")
    if not access_token:
        logger.error("FIGMA_ACCESS_TOKEN environment variable not set")
        raise ValueError("FIGMA_ACCESS_TOKEN environment variable is required")
    
    figma_client = FigmaClient(access_token)
    logger.info("Figma client initialized successfully")

@server.list_tools()
async def handle_list_tools() -> List[types.Tool]:
    """
    List available tools.
    Each tool specifies its arguments using JSON Schema validation.
    """
    return [
        types.Tool(
            name="figma.getFile",
            description="Fetch a Figma file using the Figma REST API. Requires a file key and uses the FIGMA_ACCESS_TOKEN environment variable for authentication.",
            inputSchema={
                "type": "object",
                "properties": {
                    "fileKey": {
                        "type": "string",
                        "description": "The Figma file key (found in the Figma file URL after '/file/')"
                    }
                },
                "required": ["fileKey"]
            },
        )
    ]

@server.call_tool()
async def handle_call_tool(
    name: str, arguments: Dict[str, Any]
) -> List[types.TextContent]:
    """
    Handle tool execution requests.
    """
    if figma_client is None:
        return [
            types.TextContent(
                type="text",
                text="Error: Figma client not initialized. Please ensure FIGMA_ACCESS_TOKEN environment variable is set."
            )
        ]
    
    if name == "figma.getFile":
        try:
            file_key = arguments.get("fileKey")
            if not file_key:
                return [
                    types.TextContent(
                        type="text",
                        text="Error: fileKey is required"
                    )
                ]
            
            logger.info(f"Fetching Figma file with key: {file_key}")
            file_data = await figma_client.get_file(file_key)
            
            # Format the response
            file_info = {
                "name": file_data.get("name", "Unknown"),
                "version": file_data.get("version", "Unknown"),
                "lastModified": file_data.get("lastModified", "Unknown"),
                "thumbnailUrl": file_data.get("thumbnailUrl", ""),
                "document": {
                    "id": file_data.get("document", {}).get("id", ""),
                    "name": file_data.get("document", {}).get("name", ""),
                    "type": file_data.get("document", {}).get("type", ""),
                    "children_count": len(file_data.get("document", {}).get("children", []))
                }
            }
            
            return [
                types.TextContent(
                    type="text",
                    text=f"""Figma File Retrieved Successfully:

📄 **File Information:**
- Name: {file_info['name']}
- Version: {file_info['version']}
- Last Modified: {file_info['lastModified']}
- Thumbnail: {file_info['thumbnailUrl'] if file_info['thumbnailUrl'] else 'Not available'}

📋 **Document Structure:**
- Document ID: {file_info['document']['id']}
- Document Name: {file_info['document']['name']}
- Document Type: {file_info['document']['type']}
- Children Count: {file_info['document']['children_count']}

✅ File data fetched successfully from Figma API.

*Full JSON response available in the raw data below:*
```json
{str(file_data)[:2000]}{'...' if len(str(file_data)) > 2000 else ''}
```"""
                )
            ]
            
        except FigmaAPIError as e:
            logger.error(f"Figma API error: {str(e)}")
            return [
                types.TextContent(
                    type="text",
                    text=f"❌ Figma API Error: {str(e)}\n\nPlease check:\n- File key is correct\n- Access token has permissions for this file\n- File exists and is accessible"
                )
            ]
        except Exception as e:
            logger.error(f"Unexpected error in figma.getFile: {str(e)}")
            return [
                types.TextContent(
                    type="text",
                    text=f"❌ Unexpected error: {str(e)}"
                )
            ]
    else:
        return [
            types.TextContent(
                type="text",
                text=f"❌ Unknown tool: {name}"
            )
        ]

async def main():
    """Main function to run the MCP server"""
    try:
        # Initialize Figma client
        initialize_figma_client()
        
        # Run the server using stdio transport
        async with stdio_server.stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="figma-file-extractor",
                    server_version="1.0.0",
                    capabilities=server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={},
                    ),
                ),
            )
    except Exception as e:
        logger.error(f"Server initialization failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())