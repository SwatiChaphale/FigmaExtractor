# Figma to React App

A React 18 application that generates an HTML page from Figma JSON design files.

## 🎨 Features

- **React 18** with modern hooks and components
- **Vite** for fast development and building
- **Glassmorphism UI** extracted from Figma design
- **Responsive Alert Component** with:
  - Title and description
  - Input fields with conditional rendering
  - Primary, Destructive, and Secondary buttons
  - Modern glass effect background

## 📁 Project Structure

```
figma-react-app/
├── src/
│   ├── components/
│   │   ├── Alert.jsx              # Main Alert component
│   │   ├── AlertBackground.jsx    # Glass background
│   │   ├── AlertContent.jsx       # Title & description
│   │   ├── AlertFields.jsx        # Input fields container
│   │   ├── TextField.jsx          # Individual text field
│   │   ├── AlertButtons.jsx       # Buttons container
│   │   └── Button.jsx             # Individual button
│   ├── data/
│   │   ├── file-metadata.json
│   │   ├── components.json
│   │   ├── text-elements.json
│   │   ├── buttons.json
│   │   ├── input-fields.json
│   │   ├── design-tokens.json
│   │   ├── layout-structure.json
│   │   ├── react-component-map.json
│   │   └── component-library.json
│   ├── styles/
│   │   ├── index.css
│   │   ├── App.css
│   │   ├── Alert.css
│   │   ├── AlertBackground.css
│   │   ├── AlertContent.css
│   │   ├── AlertFields.css
│   │   ├── TextField.css
│   │   ├── AlertButtons.css
│   │   └── Button.css
│   ├── App.jsx
│   └── main.jsx
├── public/
├── index.html
├── package.json
└── vite.config.js
```

## 🚀 Getting Started

### Prerequisites

- Node.js 16 or higher
- npm or yarn

### Installation

1. Navigate to the project directory:
   ```bash
   cd figma-react-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and visit:
   ```
   http://localhost:3000
   ```

## 📦 Build for Production

```bash
npm run build
```

The build files will be in the `dist/` folder.

## 🎯 Component Props

### Alert Component

```jsx
<Alert 
  showFields={true}      // Show/hide input fields
  showField2={true}      // Show/hide second field
  type="Stacked"         // Alert type
  mode="Light"           // Light/Dark mode
  textElements={...}     // Text content from JSON
  buttons={...}          // Button data from JSON
  inputFields={...}      // Input field data from JSON
  designTokens={...}     // Design tokens from JSON
/>
```

## 🎨 Design Tokens

The app uses design tokens from Figma:

- **Colors**: Fuschia and Iris variations
- **Typography**: SF Pro font family
- **Effects**: Glassmorphism with blur and shadows
- **Layout**: Auto-layout properties from Figma

## 📝 Customization

To customize the Alert component:

1. **Modify JSON data** in `src/data/` folder
2. **Update styles** in `src/styles/` folder
3. **Adjust components** in `src/components/` folder

## 🔧 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## 🌟 Features Implemented

- ✅ Glassmorphism background effect
- ✅ Conditional rendering of fields
- ✅ Three button variants (Primary, Destructive, Secondary)
- ✅ Responsive layout
- ✅ Typography from Figma
- ✅ Hover and active states
- ✅ Modern CSS with backdrop-filter

## 📄 License

MIT

## 🙏 Acknowledgments

Design extracted from Figma using the Figma API and converted to React components.
