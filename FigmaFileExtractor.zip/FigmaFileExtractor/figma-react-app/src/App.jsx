import React from 'react';
import Alert from './components/Alert';
import './styles/App.css';

// Import JSON data
import fileMetadata from './data/file-metadata.json';
import componentsData from './data/components.json';
import textElements from './data/text-elements.json';
import buttons from './data/buttons.json';
import inputFields from './data/input-fields.json';
import designTokens from './data/design-tokens.json';

function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>Figma to React</h1>
        <p>Generated from: {fileMetadata.fileInfo.name}</p>
        <p className="version">Version: {fileMetadata.fileInfo.version}</p>
      </header>
      
      <main className="app-main">
        <Alert 
          showFields={true}
          showField2={true}
          type="Stacked"
          mode="Light"
          textElements={textElements}
          buttons={buttons}
          inputFields={inputFields}
          designTokens={designTokens}
        />
      </main>
      
      <footer className="app-footer">
        <p>Last Modified: {new Date(fileMetadata.fileInfo.lastModified).toLocaleDateString()}</p>
      </footer>
    </div>
  );
}

export default App;
