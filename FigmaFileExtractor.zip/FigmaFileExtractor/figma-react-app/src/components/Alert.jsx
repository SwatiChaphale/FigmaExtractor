import React from 'react';
import AlertBackground from './AlertBackground';
import AlertContent from './AlertContent';
import AlertFields from './AlertFields';
import AlertButtons from './AlertButtons';
import '../styles/Alert.css';

const Alert = ({ 
  showFields, 
  showField2, 
  type, 
  mode,
  textElements,
  buttons,
  inputFields,
  designTokens 
}) => {
  return (
    <div className="alert-container" data-type={type} data-mode={mode}>
      <AlertBackground mode={mode} designTokens={designTokens} />
      
      <div className="alert-content-wrapper">
        <AlertContent textElements={textElements} />
        
        {showFields && (
          <AlertFields 
            inputFields={inputFields} 
            showField2={showField2}
            designTokens={designTokens}
          />
        )}
        
        <AlertButtons buttons={buttons} mode={mode} designTokens={designTokens} />
      </div>
    </div>
  );
};

export default Alert;
