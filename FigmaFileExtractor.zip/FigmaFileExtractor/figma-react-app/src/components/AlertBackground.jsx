import React from 'react';
import '../styles/AlertBackground.css';

const AlertBackground = ({ mode, designTokens }) => {
  return (
    <div className="alert-background" data-mode={mode}>
      <div className="bg-shadow">
        <div className="bg-mask"></div>
        <div className="bg-blur"></div>
      </div>
      <div className="bg-fill"></div>
      <div className="bg-glass-effect"></div>
    </div>
  );
};

export default AlertBackground;
