import React from 'react';
import '../styles/TextField.css';

const TextField = ({ field, designTokens }) => {
  const placeholder = field.properties.state === 'Placeholder' ? 'Enter text...' : '';
  const value = field.properties.state === 'Value Entered' ? 'Sample text' : '';

  return (
    <div 
      className="text-field" 
      data-state={field.properties.state.toLowerCase().replace(' ', '-')}
    >
      <input
        type={field.fieldType}
        placeholder={placeholder}
        defaultValue={value}
        className="text-field-input"
      />
    </div>
  );
};

export default TextField;
