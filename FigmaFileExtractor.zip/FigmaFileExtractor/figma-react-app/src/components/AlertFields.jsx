import React from 'react';
import TextField from './TextField';
import '../styles/AlertFields.css';

const AlertFields = ({ inputFields, showField2, designTokens }) => {
  return (
    <div className="alert-fields">
      <div className="text-field-background"></div>
      <div className="fields-container">
        {inputFields.inputFields.map((field, index) => {
          // Show field 1 always, field 2 conditionally
          if (index === 1 && !showField2) return null;
          
          return (
            <TextField
              key={field.id}
              field={field}
              designTokens={designTokens}
            />
          );
        })}
      </div>
    </div>
  );
};

export default AlertFields;
