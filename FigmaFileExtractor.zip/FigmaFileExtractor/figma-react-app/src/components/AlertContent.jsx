import React from 'react';
import '../styles/AlertContent.css';

const AlertContent = ({ textElements }) => {
  const title = textElements.textElements.find(el => el.role === 'title');
  const description = textElements.textElements.find(el => el.role === 'description');

  return (
    <div className="alert-content">
      {title && (
        <h2 className="alert-title" style={{
          fontFamily: title.style.fontFamily,
          fontSize: `${title.style.fontSize}px`,
          fontWeight: title.style.fontWeight,
          letterSpacing: `${title.style.letterSpacing}px`,
          lineHeight: `${title.style.lineHeight}px`
        }}>
          {title.content}
        </h2>
      )}
      
      {description && (
        <p className="alert-description" style={{
          fontFamily: description.style.fontFamily,
          fontSize: `${description.style.fontSize}px`,
          fontWeight: description.style.fontWeight,
          letterSpacing: `${description.style.letterSpacing}px`,
          lineHeight: `${description.style.lineHeight}px`
        }}>
          {description.content}
        </p>
      )}
    </div>
  );
};

export default AlertContent;
