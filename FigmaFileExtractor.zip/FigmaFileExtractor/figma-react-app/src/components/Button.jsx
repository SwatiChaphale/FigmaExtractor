import React from 'react';
import '../styles/Button.css';

const Button = ({ button, mode, designTokens }) => {
  const buttonType = button.properties.type.toLowerCase();
  
  return (
    <button
      className="alert-button"
      data-type={buttonType}
      data-mode={mode}
      style={{
        width: `${button.position.width}px`,
        height: `${button.position.height}px`,
        borderRadius: `${button.style.cornerRadius}px`,
        padding: `${button.layout.padding.top}px ${button.layout.padding.right}px ${button.layout.padding.bottom}px ${button.layout.padding.left}px`
      }}
    >
      {button.properties.text}
    </button>
  );
};

export default Button;
