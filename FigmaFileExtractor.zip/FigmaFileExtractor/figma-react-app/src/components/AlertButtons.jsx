import React from 'react';
import Button from './Button';
import '../styles/AlertButtons.css';

const AlertButtons = ({ buttons, mode, designTokens }) => {
  return (
    <div className="alert-buttons">
      {buttons.buttons.map((button) => (
        <Button
          key={button.id}
          button={button}
          mode={mode}
          designTokens={designTokens}
        />
      ))}
    </div>
  );
};

export default AlertButtons;
