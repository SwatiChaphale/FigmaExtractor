"""
Tests for the Figma File Extractor MCP Server
"""

import asyncio
import json
import os
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

import httpx

# Import the main module
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from main import FigmaClient, FigmaAPIError, server


class TestFigmaClient:
    """Test cases for the FigmaClient class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.access_token = "test_token_123"
        self.client = FigmaClient(self.access_token)
        self.file_key = "test_file_key_456"
    
    def test_init(self):
        """Test FigmaClient initialization"""
        assert self.client.access_token == self.access_token
        assert self.client.base_url == "https://api.figma.com/v1"
        assert self.client.headers["X-FIGMA-TOKEN"] == self.access_token
        assert self.client.headers["Content-Type"] == "application/json"
    
    @pytest.mark.asyncio
    async def test_get_file_success(self):
        """Test successful file retrieval"""
        mock_response_data = {
            "name": "Test Design File",
            "version": "1.0",
            "lastModified": "2025-11-28T12:00:00Z",
            "thumbnailUrl": "https://example.com/thumb.png",
            "document": {
                "id": "doc123",
                "name": "Document",
                "type": "DOCUMENT",
                "children": [{"id": "page1", "name": "Page 1"}]
            }
        }
        
        with patch('httpx.AsyncClient') as mock_client_class:
            mock_client = AsyncMock()
            mock_response = AsyncMock()
            mock_response.json.return_value = mock_response_data
            mock_response.raise_for_status.return_value = None
            mock_client.get.return_value = mock_response
            mock_client_class.return_value.__aenter__.return_value = mock_client
            
            result = await self.client.get_file(self.file_key)
            
            assert result == mock_response_data
            mock_client.get.assert_called_once_with(
                f"{self.client.base_url}/files/{self.file_key}",
                headers=self.client.headers
            )
    
    @pytest.mark.asyncio
    async def test_get_file_http_error(self):
        """Test HTTP error handling"""
        with patch('httpx.AsyncClient') as mock_client_class:
            mock_client = AsyncMock()
            mock_response = MagicMock()
            mock_response.status_code = 404
            mock_response.text = "File not found"
            
            http_error = httpx.HTTPStatusError(
                "404 Not Found",
                request=MagicMock(),
                response=mock_response
            )
            mock_client.get.side_effect = http_error
            mock_client_class.return_value.__aenter__.return_value = mock_client
            
            with pytest.raises(FigmaAPIError) as exc_info:
                await self.client.get_file(self.file_key)
            
            assert "HTTP 404: File not found" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_get_file_unexpected_error(self):
        """Test unexpected error handling"""
        with patch('httpx.AsyncClient') as mock_client_class:
            mock_client = AsyncMock()
            mock_client.get.side_effect = Exception("Network error")
            mock_client_class.return_value.__aenter__.return_value = mock_client
            
            with pytest.raises(FigmaAPIError) as exc_info:
                await self.client.get_file(self.file_key)
            
            assert "Unexpected error: Network error" in str(exc_info.value)


class TestMCPServer:
    """Test cases for the MCP server functionality"""
    
    @pytest.mark.asyncio
    async def test_list_tools(self):
        """Test that list_tools returns the expected tool"""
        tools = await server._list_tools_handler()
        
        assert len(tools) == 1
        tool = tools[0]
        assert tool.name == "figma.getFile"
        assert "Figma file" in tool.description
        assert "fileKey" in tool.inputSchema["properties"]
        assert tool.inputSchema["required"] == ["fileKey"]
    
    @pytest.mark.asyncio
    async def test_call_tool_missing_client(self):
        """Test tool call when Figma client is not initialized"""
        # Temporarily set figma_client to None
        import main
        original_client = main.figma_client
        main.figma_client = None
        
        try:
            result = await server._call_tool_handler("figma.getFile", {"fileKey": "test"})
            assert len(result) == 1
            assert "Error: Figma client not initialized" in result[0].text
        finally:
            main.figma_client = original_client
    
    @pytest.mark.asyncio
    async def test_call_tool_missing_file_key(self):
        """Test tool call with missing fileKey parameter"""
        # Mock the figma_client
        with patch('main.figma_client') as mock_client:
            mock_client.get_file = AsyncMock()
            
            result = await server._call_tool_handler("figma.getFile", {})
            assert len(result) == 1
            assert "Error: fileKey is required" in result[0].text
    
    @pytest.mark.asyncio
    async def test_call_tool_success(self):
        """Test successful tool call"""
        mock_file_data = {
            "name": "Test Design",
            "version": "2.0",
            "lastModified": "2025-11-28T15:30:00Z",
            "thumbnailUrl": "https://example.com/thumb.png",
            "document": {
                "id": "doc456",
                "name": "Main Document",
                "type": "DOCUMENT",
                "children": [{"id": "page1"}, {"id": "page2"}]
            }
        }
        
        with patch('main.figma_client') as mock_client:
            mock_client.get_file = AsyncMock(return_value=mock_file_data)
            
            result = await server._call_tool_handler("figma.getFile", {"fileKey": "test123"})
            
            assert len(result) == 1
            response_text = result[0].text
            assert "Figma File Retrieved Successfully" in response_text
            assert "Test Design" in response_text
            assert "version: 2.0" in response_text
            assert "Children Count: 2" in response_text
    
    @pytest.mark.asyncio
    async def test_call_tool_api_error(self):
        """Test tool call with Figma API error"""
        with patch('main.figma_client') as mock_client:
            mock_client.get_file = AsyncMock(side_effect=FigmaAPIError("Access denied"))
            
            result = await server._call_tool_handler("figma.getFile", {"fileKey": "test123"})
            
            assert len(result) == 1
            assert "❌ Figma API Error: Access denied" in result[0].text
    
    @pytest.mark.asyncio
    async def test_call_tool_unknown_tool(self):
        """Test tool call with unknown tool name"""
        result = await server._call_tool_handler("unknown.tool", {})
        
        assert len(result) == 1
        assert "❌ Unknown tool: unknown.tool" in result[0].text


class TestIntegration:
    """Integration tests"""
    
    def test_environment_variable_handling(self):
        """Test environment variable handling"""
        import main
        
        # Test missing environment variable
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="FIGMA_ACCESS_TOKEN environment variable is required"):
                main.initialize_figma_client()
        
        # Test with environment variable set
        with patch.dict(os.environ, {"FIGMA_ACCESS_TOKEN": "test_token"}):
            main.initialize_figma_client()
            assert main.figma_client is not None
            assert main.figma_client.access_token == "test_token"


if __name__ == "__main__":
    pytest.main([__file__])