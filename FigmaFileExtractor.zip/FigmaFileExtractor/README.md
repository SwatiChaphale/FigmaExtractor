# Figma File Extractor MCP Server

A Model Context Protocol (MCP) server that provides tools to interact with the Figma REST API for extracting file information.

## Features

- 🎨 **Figma API Integration**: Fetch complete Figma file data using file keys
- 🔐 **Secure Authentication**: Uses personal access tokens via environment variables
- 📊 **Structured Output**: Returns formatted file information and metadata
- 🚀 **MCP Compatible**: Works with any MCP-compatible client (Claude Desktop, etc.)

## Prerequisites

- Python 3.8 or higher
- A Figma Personal Access Token
- Figma file access permissions

## Installation

1. **Clone or download this repository:**
   ```bash
   cd FigmaFileExtractor
   ```

2. **Install the package and dependencies:**
   ```bash
   pip install -e .
   ```

   Or install dependencies directly:
   ```bash
   pip install mcp httpx pydantic
   ```

3. **Set up your Figma Personal Access Token:**
   
   Create a `.env` file in the project directory:
   ```env
   FIGMA_ACCESS_TOKEN=your_figma_personal_access_token_here
   ```
   
   Or set the environment variable directly:
   ```bash
   # Windows PowerShell
   $env:FIGMA_ACCESS_TOKEN="your_figma_personal_access_token_here"
   
   # Windows Command Prompt
   set FIGMA_ACCESS_TOKEN=your_figma_personal_access_token_here
   
   # Linux/Mac
   export FIGMA_ACCESS_TOKEN="your_figma_personal_access_token_here"
   ```

## Getting a Figma Personal Access Token

1. Go to [Figma Account Settings](https://www.figma.com/settings)
2. Scroll down to "Personal Access Tokens"
3. Click "Create a new personal access token"
4. Give it a name (e.g., "MCP Server")
5. Copy the generated token
6. Keep this token secure - it provides access to your Figma files

## Usage

### Running the Server

```bash
python main.py
```

The server will start and listen for MCP requests via standard input/output.

### Available Tools

#### `figma.getFile`

Fetches a Figma file using the Figma REST API.

**Parameters:**
- `fileKey` (string, required): The Figma file key found in the URL

**Example file key extraction:**
From URL: `https://www.figma.com/file/ABC123DEF456/My-Design-File`
The file key is: `ABC123DEF456`

**Example Usage:**
```json
{
  "name": "figma.getFile",
  "arguments": {
    "fileKey": "ABC123DEF456"
  }
}
```

**Response includes:**
- File name and metadata
- Version information
- Last modified timestamp
- Thumbnail URL (if available)
- Document structure overview
- Full JSON response (truncated for readability)

## Integration with MCP Clients

### Claude Desktop

Add this server to your Claude Desktop configuration:

1. Edit your Claude Desktop config file:
   - **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
   - **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

2. Add the server configuration:
   ```json
   {
     "mcpServers": {
       "figma-file-extractor": {
         "command": "python",
         "args": ["C:\\path\\to\\FigmaFileExtractor\\main.py"],
         "env": {
           "FIGMA_ACCESS_TOKEN": "your_figma_personal_access_token_here"
         }
       }
     }
   }
   ```

3. Restart Claude Desktop

### Other MCP Clients

This server follows the standard MCP protocol and should work with any MCP-compatible client.

## Development

### Installing Development Dependencies

```bash
pip install -e ".[dev]"
```

### Code Formatting

```bash
black main.py
isort main.py
```

### Type Checking

```bash
mypy main.py
```

### Testing

```bash
pytest tests/
```

## API Reference

### Figma REST API

This server uses the [Figma REST API v1](https://www.figma.com/developers/api):

- **Endpoint**: `GET https://api.figma.com/v1/files/{file_key}`
- **Authentication**: Personal Access Token via `X-FIGMA-TOKEN` header
- **Rate Limits**: Figma applies rate limiting (typically 100 requests per minute)

### Error Handling

The server provides detailed error messages for common issues:

- **Missing Access Token**: Check environment variable setup
- **Invalid File Key**: Verify the file key format and permissions
- **API Rate Limits**: Figma API rate limiting messages
- **Network Issues**: Connection and timeout errors
- **Authentication Errors**: Token validation and permissions

## File Structure

```
FigmaFileExtractor/
├── main.py              # Main MCP server implementation
├── pyproject.toml       # Python project configuration
├── README.md            # This file
├── .env.example         # Example environment file
└── prompt.md           # Original project prompt
```

## Security Notes

- Never commit your Figma Personal Access Token to version control
- Store tokens in environment variables or secure configuration files
- Regularly rotate your access tokens
- Only grant necessary permissions to your tokens

## Troubleshooting

### Common Issues

1. **"FIGMA_ACCESS_TOKEN environment variable not set"**
   - Ensure you've set the environment variable correctly
   - Check the variable name spelling

2. **"HTTP 403: Forbidden"**
   - Verify your access token is valid
   - Check if you have permissions to access the specific file
   - Ensure the file exists and is accessible

3. **"HTTP 404: Not Found"**
   - Double-check the file key format
   - Ensure the file hasn't been deleted or moved

4. **Rate Limiting**
   - Wait a few minutes before retrying
   - Consider implementing request throttling for high-volume usage

### Debug Mode

Set logging level to DEBUG for more detailed output:

```python
logging.basicConfig(level=logging.DEBUG)
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Support

If you encounter any issues or have questions:

1. Check the troubleshooting section above
2. Review Figma API documentation
3. Open an issue on GitHub
4. Check MCP protocol documentation