"""
Simple Figma API test without MCP dependencies
"""

import asyncio
import os
import json
import httpx


class FigmaAPIError(Exception):
    """Custom exception for Figma API errors"""
    pass


class FigmaClient:
    """Client for interacting with the Figma API"""
    
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.base_url = "https://api.figma.com/v1"
        self.headers = {
            "X-FIGMA-TOKEN": access_token,
            "Content-Type": "application/json"
        }
    
    async def get_file(self, file_key: str) -> dict:
        """
        Fetch a Figma file by its key
        
        Args:
            file_key: The Figma file key (found in the URL)
            
        Returns:
            Dict containing the file data
            
        Raises:
            FigmaAPIError: If the API request fails
        """
        url = f"{self.base_url}/files/{file_key}"
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                error_msg = f"HTTP {e.response.status_code}: {e.response.text}"
                raise FigmaAPIError(error_msg)
            except Exception as e:
                raise FigmaAPIError(f"Unexpected error: {str(e)}")


async def test_figma_api():
    """Test the Figma API with your credentials"""
    
    # Get access token from environment
    access_token = os.getenv("FIGMA_ACCESS_TOKEN")
    if not access_token:
        print("❌ FIGMA_ACCESS_TOKEN environment variable not set")
        return
    
    print(f"🔑 Using token: {access_token[:15]}...")
    
    # Your file key
    file_key = "tQjyApQ24o5Ebhzir3gxaY"
    print(f"📁 Testing file key: {file_key}")
    
    # Initialize client
    client = FigmaClient(access_token)
    
    try:
        print(f"\n🔄 Fetching Figma file...")
        file_data = await client.get_file(file_key)
        
        print("✅ SUCCESS! File retrieved successfully")
        print(f"📄 File Name: {file_data.get('name', 'Unknown')}")
        print(f"🔢 Version: {file_data.get('version', 'Unknown')}")
        print(f"⏰ Last Modified: {file_data.get('lastModified', 'Unknown')}")
        
        # Document info
        document = file_data.get('document', {})
        children = document.get('children', [])
        print(f"📋 Document has {len(children)} top-level items")
        
        if children:
            print("\n📁 Top-level pages/frames:")
            for i, child in enumerate(children[:5]):
                print(f"   {i+1}. {child.get('name', 'Unnamed')} ({child.get('type', 'Unknown')})")
            if len(children) > 5:
                print(f"   ... and {len(children) - 5} more")
        
        # Save response
        output_file = f"figma_response_{file_key}.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(file_data, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Full response saved to: {output_file}")
        
        return True
        
    except FigmaAPIError as e:
        print(f"❌ Figma API Error: {e}")
        print("\n🔍 Common issues:")
        print("   • File key might be incorrect")
        print("   • You might not have access to this file")
        print("   • Token might be invalid or expired")
        return False
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False


if __name__ == "__main__":
    print("🚀 Figma API Test")
    print("=" * 30)
    
    try:
        success = asyncio.run(test_figma_api())
        if success:
            print("\n🎉 Test completed successfully!")
        else:
            print("\n💥 Test failed - check the errors above")
    except Exception as e:
        print(f"❌ Error running test: {e}")