#!/usr/bin/env python3
"""
Figma File Extractor MCP Server

This server provides tools to interact with the Figma API to fetch file information.
"""

import asyncio
import os
import sys
from typing import Any, Dict, List, Optional
import logging
import json

import httpx
from mcp.server.fastmcp import FastMCP


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the MCP server using FastMCP
app = FastMCP("Figma File Extractor")

class FigmaAPIError(Exception):
    """Custom exception for Figma API errors"""
    pass

class FigmaClient:
    """Client for interacting with the Figma API"""
    
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.base_url = "https://api.figma.com/v1"
        self.headers = {
            "X-FIGMA-TOKEN": access_token,
            "Content-Type": "application/json"
        }
    
    async def get_file(self, file_key: str) -> Dict[str, Any]:
        """
        Fetch a Figma file by its key
        
        Args:
            file_key: The Figma file key (found in the URL)
            
        Returns:
            Dict containing the file data
            
        Raises:
            FigmaAPIError: If the API request fails
        """
        url = f"{self.base_url}/files/{file_key}"
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                error_msg = f"HTTP {e.response.status_code}: {e.response.text}"
                logger.error(f"Figma API request failed: {error_msg}")
                raise FigmaAPIError(error_msg)
            except Exception as e:
                logger.error(f"Unexpected error during API request: {str(e)}")
                raise FigmaAPIError(f"Unexpected error: {str(e)}")

# Global Figma client (will be initialized with access token)
figma_client: Optional[FigmaClient] = None

def initialize_figma_client():
    """Initialize the Figma client with access token from environment"""
    global figma_client
    
    # Try to load from .env file first
    access_token = None
    env_file = ".env"
    
    if os.path.exists(env_file):
        try:
            with open(env_file, 'r') as f:
                for line in f:
                    if line.strip().startswith("FIGMA_ACCESS_TOKEN="):
                        access_token = line.strip().split("=", 1)[1]
                        break
        except Exception as e:
            logger.warning(f"Could not read .env file: {e}")
    
    # Fallback to environment variable
    if not access_token:
        access_token = os.getenv("FIGMA_ACCESS_TOKEN")
    
    if not access_token:
        logger.error("FIGMA_ACCESS_TOKEN not found in .env file or environment variable")
        raise ValueError("FIGMA_ACCESS_TOKEN is required")
    
    figma_client = FigmaClient(access_token)
    logger.info(f"Figma client initialized successfully with token: {access_token[:15]}...")

@app.tool()
async def figma_getFile(file_key: str) -> str:
    """
    Fetch a Figma file using the Figma REST API.
    
    Args:
        file_key: The Figma file key (found in the Figma file URL after '/file/')
        
    Returns:
        A formatted string with file information and metadata
    """
    if figma_client is None:
        return "Error: Figma client not initialized. Please ensure FIGMA_ACCESS_TOKEN environment variable is set."
    
    if not file_key:
        return "Error: fileKey is required"
    
    try:
        logger.info(f"Fetching Figma file with key: {file_key}")
        file_data = await figma_client.get_file(file_key)
        
        # Format the response
        file_info = {
            "name": file_data.get("name", "Unknown"),
            "version": file_data.get("version", "Unknown"),
            "lastModified": file_data.get("lastModified", "Unknown"),
            "thumbnailUrl": file_data.get("thumbnailUrl", ""),
            "document": {
                "id": file_data.get("document", {}).get("id", ""),
                "name": file_data.get("document", {}).get("name", ""),
                "type": file_data.get("document", {}).get("type", ""),
                "children_count": len(file_data.get("document", {}).get("children", []))
            }
        }
        
        result = f"""Figma File Retrieved Successfully:

📄 **File Information:**
- Name: {file_info['name']}
- Version: {file_info['version']}
- Last Modified: {file_info['lastModified']}
- Thumbnail: {file_info['thumbnailUrl'] if file_info['thumbnailUrl'] else 'Not available'}

📋 **Document Structure:**
- Document ID: {file_info['document']['id']}
- Document Name: {file_info['document']['name']}
- Document Type: {file_info['document']['type']}
- Children Count: {file_info['document']['children_count']}

✅ File data fetched successfully from Figma API.

*Sample data structure:*
```json
{json.dumps(file_info, indent=2)}
```"""
        
        return result
        
    except FigmaAPIError as e:
        logger.error(f"Figma API error: {str(e)}")
        return f"❌ Figma API Error: {str(e)}\n\nPlease check:\n- File key is correct\n- Access token has permissions for this file\n- File exists and is accessible"
    except Exception as e:
        logger.error(f"Unexpected error in figma_getFile: {str(e)}")
        return f"❌ Unexpected error: {str(e)}"

def main():
    """Main function to run the MCP server"""
    try:
        # Initialize Figma client
        initialize_figma_client()
        logger.info("Figma MCP Server starting...")
        
        # Run the FastMCP server
        app.run()
        
    except Exception as e:
        logger.error(f"Server initialization failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()